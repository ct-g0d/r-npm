module.exports = { id: 40, name: "pkg-tier3-stress-040" };
