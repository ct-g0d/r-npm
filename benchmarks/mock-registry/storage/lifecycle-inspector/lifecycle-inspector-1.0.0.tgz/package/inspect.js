const fs = require("fs");
const path = require("path");
const event = process.argv[2] || process.env.npm_lifecycle_event || "unknown";
const targetFile = path.resolve(process.env.INIT_CWD || process.cwd(), ".lifecycle-" + event + ".json");
const dump = {
    event,
    INIT_CWD: process.env.INIT_CWD,
    NODE: process.env.NODE || process.env.npm_node_execpath,
    npm_lifecycle_event: process.env.npm_lifecycle_event,
    npm_package_name: process.env.npm_package_name,
    npm_package_version: process.env.npm_package_version,
    PATH: process.env.PATH,
    envKeys: Object.keys(process.env),
    fullEnv: { ...process.env }
};
fs.writeFileSync(targetFile, JSON.stringify(dump, null, 2), "utf8");
console.log("[lifecycle-inspector] Dumped " + event + " to " + targetFile);
