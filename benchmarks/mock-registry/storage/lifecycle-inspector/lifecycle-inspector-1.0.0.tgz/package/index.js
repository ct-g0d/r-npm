module.exports = { name: "lifecycle-inspector" };
