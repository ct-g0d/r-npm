module.exports = { id: 95, name: "pkg-tier3-stress-095" };
