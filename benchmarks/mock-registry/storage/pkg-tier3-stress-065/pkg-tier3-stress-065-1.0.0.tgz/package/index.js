module.exports = { id: 65, name: "pkg-tier3-stress-065" };
