module.exports = { id: 17, name: "pkg-tier3-stress-017" };
