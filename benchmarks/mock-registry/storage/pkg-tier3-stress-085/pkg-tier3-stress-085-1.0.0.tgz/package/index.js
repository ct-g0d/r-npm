module.exports = { id: 85, name: "pkg-tier3-stress-085" };
