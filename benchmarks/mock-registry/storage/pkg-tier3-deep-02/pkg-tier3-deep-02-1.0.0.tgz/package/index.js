module.exports = { level: 2, name: "pkg-tier3-deep-02" };
