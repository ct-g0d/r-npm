module.exports = { id: 96, name: "pkg-tier3-stress-096" };
