const bottom = require("pkg-diamond-bottom"); module.exports = { name: "pkg-diamond-right", version: "1.0.0", bottom };
