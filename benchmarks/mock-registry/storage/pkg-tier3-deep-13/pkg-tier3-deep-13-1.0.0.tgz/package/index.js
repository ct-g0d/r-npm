module.exports = { level: 13, name: "pkg-tier3-deep-13" };
