module.exports = { name: "pkg-deep-shared", shared: true };
