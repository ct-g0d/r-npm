module.exports = { helper: true, version: "1.0.0" };
