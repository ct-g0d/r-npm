module.exports = { id: 87, name: "pkg-tier3-stress-087" };
