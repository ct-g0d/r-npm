module.exports = { level: 12, name: "pkg-tier3-deep-12" };
