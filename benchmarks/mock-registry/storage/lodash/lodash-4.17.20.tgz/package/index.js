module.exports = { isArray: Array.isArray, isObject: (v) => typeof v === "object", version: "4.17.20" };
