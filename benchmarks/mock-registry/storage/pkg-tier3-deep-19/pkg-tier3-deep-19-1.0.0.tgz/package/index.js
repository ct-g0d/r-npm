module.exports = { level: 19, name: "pkg-tier3-deep-19" };
