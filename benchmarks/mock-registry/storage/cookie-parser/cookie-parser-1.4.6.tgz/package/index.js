module.exports = (secret) => (req, res, next) => { req.cookies = {}; if (next) next(); };
