module.exports = { red: [255, 0, 0], green: [0, 255, 0] };
