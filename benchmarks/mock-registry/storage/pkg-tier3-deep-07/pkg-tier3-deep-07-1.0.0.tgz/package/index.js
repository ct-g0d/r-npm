module.exports = { level: 7, name: "pkg-tier3-deep-07" };
