module.exports = { level: 11, name: "pkg-tier3-deep-11" };
