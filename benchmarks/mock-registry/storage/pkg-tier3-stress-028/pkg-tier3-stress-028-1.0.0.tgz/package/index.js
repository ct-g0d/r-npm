module.exports = { id: 28, name: "pkg-tier3-stress-028" };
