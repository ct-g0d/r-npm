module.exports = { id: 2, name: "pkg-tier3-stress-002" };
