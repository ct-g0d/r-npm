module.exports = { id: 52, name: "pkg-tier3-stress-052" };
