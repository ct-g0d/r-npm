const bytes = require("bytes");
const rawBody = require("raw-body");
module.exports = {
    json: (opts) => (req, res, next) => { if (next) next(); },
    urlencoded: (opts) => (req, res, next) => { if (next) next(); }
};
