module.exports = { id: 34, name: "pkg-tier3-stress-034" };
