module.exports = { name: "@scope/pkg-beta", version: "1.0.0" };
