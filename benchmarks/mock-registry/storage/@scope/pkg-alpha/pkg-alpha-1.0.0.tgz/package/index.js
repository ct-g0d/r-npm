module.exports = { name: "@scope/pkg-alpha", version: "1.0.0" };
