module.exports = /token/;
