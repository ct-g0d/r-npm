const bottom = require("pkg-diamond-bottom"); module.exports = { name: "pkg-diamond-left", version: "1.0.0", bottom };
