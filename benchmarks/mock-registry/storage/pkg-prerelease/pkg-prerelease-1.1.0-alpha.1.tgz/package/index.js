module.exports = { name: "pkg-prerelease", version: "1.1.0-alpha.1" };
