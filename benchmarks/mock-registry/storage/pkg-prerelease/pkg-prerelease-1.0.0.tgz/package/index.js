module.exports = { name: "pkg-prerelease", version: "1.0.0" };
