module.exports = { level: 23, name: "pkg-tier3-deep-23" };
