module.exports = { level: 5, name: "pkg-tier3-deep-05" };
