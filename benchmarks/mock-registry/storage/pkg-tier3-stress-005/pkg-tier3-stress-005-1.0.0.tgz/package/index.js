module.exports = { id: 5, name: "pkg-tier3-stress-005" };
