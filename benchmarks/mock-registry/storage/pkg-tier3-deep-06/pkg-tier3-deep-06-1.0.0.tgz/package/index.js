module.exports = { level: 6, name: "pkg-tier3-deep-06" };
