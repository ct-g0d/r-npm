module.exports = { id: 110, name: "pkg-tier3-stress-110" };
