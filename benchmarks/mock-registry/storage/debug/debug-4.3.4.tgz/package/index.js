module.exports = (namespace) => {
    const fn = (...args) => {};
    fn.enabled = false;
    return fn;
};
