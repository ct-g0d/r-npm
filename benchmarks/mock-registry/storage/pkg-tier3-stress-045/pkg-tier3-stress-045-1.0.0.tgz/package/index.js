module.exports = { id: 45, name: "pkg-tier3-stress-045" };
