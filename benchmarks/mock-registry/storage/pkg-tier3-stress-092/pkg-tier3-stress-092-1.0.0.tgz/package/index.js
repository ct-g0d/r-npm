module.exports = { id: 92, name: "pkg-tier3-stress-092" };
