module.exports = { id: 6, name: "pkg-tier3-stress-006" };
