module.exports = { level: 22, name: "pkg-tier3-deep-22" };
