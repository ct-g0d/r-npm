module.exports = (val) => (typeof val === "number" ? `${val}B` : 1024);
