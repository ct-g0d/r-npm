const b = require("pkg-deep-b"); module.exports = { name: "pkg-deep-a", b };
