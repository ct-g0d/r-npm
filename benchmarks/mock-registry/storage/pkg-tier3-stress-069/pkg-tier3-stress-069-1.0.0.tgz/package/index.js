module.exports = { id: 69, name: "pkg-tier3-stress-069" };
