class Command {
    constructor(name = "") { this._name = name; this._options = []; }
    name(n) { this._name = n; return this; }
    version(v) { this._version = v; return this; }
    description(d) { this._description = d; return this; }
    option(flags, desc) { this._options.push({ flags, desc }); return this; }
    parse(argv) { this.parsed = true; return this; }
}
module.exports = { Command, program: new Command("root") };
