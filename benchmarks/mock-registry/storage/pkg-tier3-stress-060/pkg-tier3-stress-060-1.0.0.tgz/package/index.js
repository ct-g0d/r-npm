module.exports = { id: 60, name: "pkg-tier3-stress-060" };
