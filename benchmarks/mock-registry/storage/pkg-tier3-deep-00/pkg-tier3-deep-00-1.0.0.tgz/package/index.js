module.exports = { level: 0, name: "pkg-tier3-deep-00" };
