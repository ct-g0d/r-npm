module.exports = { id: 74, name: "pkg-tier3-stress-074" };
