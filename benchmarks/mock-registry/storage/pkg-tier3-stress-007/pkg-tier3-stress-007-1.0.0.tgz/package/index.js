module.exports = { id: 7, name: "pkg-tier3-stress-007" };
