const e = require("pkg-deep-e"); const shared = require("pkg-deep-shared"); module.exports = { name: "pkg-deep-d", e, shared };
