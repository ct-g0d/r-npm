module.exports = { id: 100, name: "pkg-tier3-stress-100" };
