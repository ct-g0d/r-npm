module.exports = { level: 10, name: "pkg-tier3-deep-10" };
