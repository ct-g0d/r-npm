module.exports = { name: "pkg-deep-e", leaf: true };
