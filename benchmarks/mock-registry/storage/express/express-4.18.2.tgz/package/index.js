const accepts = require("accepts");
const mimeTypes = require("mime-types");
const debug = require("debug")("express:main");
const depd = require("depd")("express");

function createApplication() {
    const app = {
        _routes: [],
        _middlewares: [],
        use(fn) { app._middlewares.push(fn); return app; },
        get(path, handler) { app._routes.push({ method: "GET", path, handler }); return app; },
        post(path, handler) { app._routes.push({ method: "POST", path, handler }); return app; },
        listen(port, cb) {
            if (cb) cb();
            return { close(c) { if (c) c(); } };
        }
    };
    return app;
}
module.exports = createApplication;
