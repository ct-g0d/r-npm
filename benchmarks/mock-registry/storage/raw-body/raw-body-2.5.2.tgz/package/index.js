const bytes = require("bytes");
module.exports = (stream) => Promise.resolve(Buffer.alloc(0));
