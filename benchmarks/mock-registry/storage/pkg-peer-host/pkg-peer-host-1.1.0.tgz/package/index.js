module.exports = { name: "pkg-peer-host", version: "1.1.0" };
