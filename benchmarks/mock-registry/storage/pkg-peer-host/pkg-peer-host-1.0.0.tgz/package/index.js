module.exports = { name: "pkg-peer-host", version: "1.0.0" };
