module.exports = { level: 25, name: "pkg-tier3-deep-25" };
