const d = require("pkg-deep-d"); module.exports = { name: "pkg-deep-c", d };
