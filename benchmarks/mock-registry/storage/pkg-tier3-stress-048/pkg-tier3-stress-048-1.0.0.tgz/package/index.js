module.exports = { id: 48, name: "pkg-tier3-stress-048" };
