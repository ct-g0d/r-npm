module.exports = { id: 42, name: "pkg-tier3-stress-042" };
