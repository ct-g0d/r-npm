module.exports = { id: 79, name: "pkg-tier3-stress-079" };
