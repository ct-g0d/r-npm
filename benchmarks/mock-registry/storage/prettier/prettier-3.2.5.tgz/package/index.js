module.exports = { format: (s) => s, version: "3.2.5" };
