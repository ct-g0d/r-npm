module.exports = { name: "pkg-single-a", version: "1.0.0" };
