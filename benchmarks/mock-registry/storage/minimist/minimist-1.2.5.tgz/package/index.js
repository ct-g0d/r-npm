module.exports = (args) => ({ _: args });
