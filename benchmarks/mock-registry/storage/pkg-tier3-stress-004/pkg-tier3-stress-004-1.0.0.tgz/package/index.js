module.exports = { id: 4, name: "pkg-tier3-stress-004" };
