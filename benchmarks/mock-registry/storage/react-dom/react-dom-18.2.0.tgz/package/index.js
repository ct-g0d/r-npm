const React = require("react"); module.exports = { render: () => {}, version: "18.2.0" };
