module.exports = { id: 1, name: "pkg-tier3-stress-001" };
