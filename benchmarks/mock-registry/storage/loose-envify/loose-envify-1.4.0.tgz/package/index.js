module.exports = (s) => s;
