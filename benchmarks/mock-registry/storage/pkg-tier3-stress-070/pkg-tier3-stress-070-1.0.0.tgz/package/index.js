module.exports = { id: 70, name: "pkg-tier3-stress-070" };
