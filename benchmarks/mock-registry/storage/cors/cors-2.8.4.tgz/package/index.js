module.exports = (opts) => (req, res, next) => { if (next) next(); };
