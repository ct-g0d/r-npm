const c = require("pkg-deep-c"); module.exports = { name: "pkg-deep-b", c };
