module.exports = { level: 4, name: "pkg-tier3-deep-04" };
