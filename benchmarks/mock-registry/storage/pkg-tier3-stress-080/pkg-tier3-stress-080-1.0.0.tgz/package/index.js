module.exports = { id: 80, name: "pkg-tier3-stress-080" };
