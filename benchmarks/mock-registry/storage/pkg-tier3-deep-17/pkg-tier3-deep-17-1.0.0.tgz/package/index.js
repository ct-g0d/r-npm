module.exports = { level: 17, name: "pkg-tier3-deep-17" };
