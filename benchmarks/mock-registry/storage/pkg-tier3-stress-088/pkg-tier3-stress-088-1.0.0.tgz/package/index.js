module.exports = { id: 88, name: "pkg-tier3-stress-088" };
