module.exports = { level: 24, name: "pkg-tier3-deep-24" };
