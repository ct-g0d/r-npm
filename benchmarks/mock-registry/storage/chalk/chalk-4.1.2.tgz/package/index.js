module.exports = { red: (s) => `\u001b[31m${s}\u001b[39m`, green: (s) => s };
