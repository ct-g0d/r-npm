module.exports = { id: 32, name: "pkg-tier3-stress-032" };
