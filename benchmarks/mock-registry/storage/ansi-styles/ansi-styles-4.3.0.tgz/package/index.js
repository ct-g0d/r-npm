module.exports = { red: { open: "\u001b[31m", close: "\u001b[39m" } };
