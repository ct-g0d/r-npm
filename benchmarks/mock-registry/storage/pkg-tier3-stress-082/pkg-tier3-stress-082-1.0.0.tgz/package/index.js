module.exports = { id: 82, name: "pkg-tier3-stress-082" };
