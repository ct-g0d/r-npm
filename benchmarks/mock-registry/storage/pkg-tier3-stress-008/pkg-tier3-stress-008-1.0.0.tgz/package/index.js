module.exports = { id: 8, name: "pkg-tier3-stress-008" };
