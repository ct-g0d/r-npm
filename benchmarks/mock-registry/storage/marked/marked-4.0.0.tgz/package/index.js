module.exports = { parse: (s) => `<p>${s}</p>` };
