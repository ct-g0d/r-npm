module.exports = { id: 50, name: "pkg-tier3-stress-050" };
