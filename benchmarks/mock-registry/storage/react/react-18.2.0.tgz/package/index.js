module.exports = { createElement: () => ({}), version: "18.2.0" };
