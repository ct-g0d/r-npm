const mimeTypes = require("mime-types");
module.exports = (req) => ({
    type: (types) => types[0] || false,
    charsets: () => ["utf-8"]
});
