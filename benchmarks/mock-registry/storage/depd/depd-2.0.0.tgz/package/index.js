module.exports = (namespace) => (msg) => {};
