module.exports = { level: 20, name: "pkg-tier3-deep-20" };
