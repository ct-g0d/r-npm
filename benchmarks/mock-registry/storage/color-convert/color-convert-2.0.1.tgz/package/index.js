module.exports = { rgb: { ansi256: () => 1 } };
