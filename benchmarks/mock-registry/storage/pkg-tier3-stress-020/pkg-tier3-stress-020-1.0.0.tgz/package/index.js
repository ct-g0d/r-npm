module.exports = { id: 20, name: "pkg-tier3-stress-020" };
