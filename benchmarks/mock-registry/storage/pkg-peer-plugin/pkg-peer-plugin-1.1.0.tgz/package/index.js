module.exports = { name: "pkg-peer-plugin", version: "1.1.0" };
