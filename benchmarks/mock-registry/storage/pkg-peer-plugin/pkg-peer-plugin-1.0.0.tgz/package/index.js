module.exports = { name: "pkg-peer-plugin", version: "1.0.0" };
