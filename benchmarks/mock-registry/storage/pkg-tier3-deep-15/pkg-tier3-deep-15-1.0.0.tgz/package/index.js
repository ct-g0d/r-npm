module.exports = { level: 15, name: "pkg-tier3-deep-15" };
