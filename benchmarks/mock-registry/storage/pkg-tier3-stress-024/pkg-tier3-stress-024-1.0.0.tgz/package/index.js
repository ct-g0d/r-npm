module.exports = { id: 24, name: "pkg-tier3-stress-024" };
