module.exports = { stdout: { level: 2, hasBasic: true } };
