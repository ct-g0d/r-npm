module.exports = { level: 18, name: "pkg-tier3-deep-18" };
