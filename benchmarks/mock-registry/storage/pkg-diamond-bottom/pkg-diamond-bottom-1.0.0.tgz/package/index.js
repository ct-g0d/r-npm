module.exports = { name: "pkg-diamond-bottom", version: "1.0.0" };
