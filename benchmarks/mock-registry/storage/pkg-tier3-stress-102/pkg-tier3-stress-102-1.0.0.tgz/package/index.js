module.exports = { id: 102, name: "pkg-tier3-stress-102" };
