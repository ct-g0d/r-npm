const db = require("mime-db");
module.exports = {
    lookup: (path) => db["json"] || false,
    contentType: (type) => "application/json; charset=utf-8"
};
