module.exports = { level: 8, name: "pkg-tier3-deep-08" };
